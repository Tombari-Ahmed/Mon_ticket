<?php
session_start();
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title> Ajouter un nouveau ticket </title>
<link rel="stylesheet" href="MonTicket.css">

</head>

<body>
<div id="container">
<?php include('message.php'); ?>
	<form name="formadd" action="code.php" method="POST" class="formulaire" enctype="multipart/form-data">
		<h2 align="center">Ajouter un nouveau ticket :</h2>
                <label><b> Catégorie</b></label>
                <select class="zonetext" name="categorie" id="categorie" required>
                        <option value="">Entrer la Catégorie</option>
                        <option value="cinema">Cinéma</option>
                        <option value="musique">Musique</option>
                        <option value="sport">Sport</option>
                        <option value="spectacle ">Spectacle </option>
                    </select>
                
                <label><b>Nom d'evenement</b></label>
                <input class="zonetext" type="text" placeholder="Entrer le Nom d'évènement" name="nom_devenement" required>

               <label><b>Prix Ticket</b></label>
                <input class="zonetext" type="text" placeholder="Entrer le Prix de Ticket" name="prix_ticket" required>
              
                <label><b>Date d'evenement</b></label>
                <input class="zonetext" type="date" placeholder="Entrer la Date" name="date_devenement" required>
                <label><b>Lieu d'evenement</b></label>
                <input class="zonetext" type="text" placeholder="Entrer la Lieu" name="lieu_devenement" required>

                <label><b>Quantité de Ticket</b></label>
                <input class="zonetext" type="number" placeholder="Entrer la Quantité" min="1" name="quantite_ticket" required>
                
                <label><b>Photo de Ticket</b></label>
                <input class="zonetext" type="file" placeholder="choisir une photo de Ticket" name="photo_ticket" required>
                
                <input type="submit" name="save_ticket" class="submit">
                
		<p><a href="dashboard.php" class="submit" >Tableau de Bord</a></p>
                
                <label style="text-align: center;color: #360001;">

                </label>
	</form>
	

	
</div>


</body>
</html>