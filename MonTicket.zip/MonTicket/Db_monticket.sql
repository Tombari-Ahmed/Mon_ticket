-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : ven. 13 mai 2022 à 14:20
-- Version du serveur : 5.7.36
-- Version de PHP : 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `monticket`
--

-- --------------------------------------------------------

--
-- Structure de la table `ticket`
--

DROP TABLE IF EXISTS `ticket`;
CREATE TABLE IF NOT EXISTS `ticket` (
  `id` int(200) NOT NULL AUTO_INCREMENT,
  `categorie` varchar(200) NOT NULL,
  `nom_devenement` varchar(255) NOT NULL,
  `lieu_devenement` varchar(255) NOT NULL,
  `quantite_ticket` int(100) NOT NULL,
  `prix_ticket` varchar(20) NOT NULL,
  `photo_ticket` varchar(255) NOT NULL,
  `date_devenement` date NOT NULL,
  `id_users` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_users` (`id_users`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `ticket`
--

INSERT INTO `ticket` (`id`, `categorie`, `nom_devenement`, `lieu_devenement`, `quantite_ticket`, `prix_ticket`, `photo_ticket`, `date_devenement`, `id_users`) VALUES
(2, 'sport', 'dfg', 'bjklgjk', 1, '4141', '', '2022-04-30', NULL),
(3, 'cinema', 'test2', 'test2', 11, '4141', '', '2022-05-13', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `role` varchar(100) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mot_passe` varchar(200) NOT NULL,
  `id_ticket` int(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_ticket` (`id_ticket`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `nom`, `role`, `telephone`, `email`, `mot_passe`, `id_ticket`) VALUES
(1, 'test', 'admin', '13212', 'test@test.com', '123456', 1),
(2, 'user', 'user', '41414', 'user@user.com', '123456', 2),
(3, 'admin', '', '123456', 'admin@admin.com', '123456', NULL),
(4, 'admin1', 'admin', '123456', 'admin1@admin.com', '123456', NULL),
(5, 'testuser', 'user', '123123123', 'testuser@gmail.com', '123456', NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
