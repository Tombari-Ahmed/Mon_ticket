<?php
    session_start();
    require 'dbcon.php';
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Tableau de Bord...User</title>
<link rel="stylesheet" href="MonTicket.css">
<style>

.photoTicket{
	width: 300px;height: 128px;border-radius: 5%;border: 1px solid;
}

	</style>

</head>


<p><h1><b>Liste des tickets :</b></h1>	</p>
	<p><a href="Ajouter.php"><img src="images/ajouter.png" width="50px" height="100px"></a></p>
<table width="100%" border="1">
  <body>
  <a href='user_display.php?deconnexion=true'><span>Déconnexion</span></a>
            
            <!-- tester si l'utilisateur est connecté -->
            <?php
               
                if(isset($_GET['deconnexion']))
                { 
                   if($_GET['deconnexion']==true)
                   {  
                      session_unset();
                      header('Location: login.php');
                   }
                }
                else if($_SESSION['email'] !== ""){
                    $user = $_SESSION['email'];
                    // afficher un message
                    echo "<br>Bonjour $user, vous êtes connectés";
                }
            ?>
  <?php include('message.php'); ?>
    <div>
    <tr>
      <th> Catégorie</th>
      <th>Id Ticket</th>
      <th>Nom d'evenement</th>
      <th>Prix Ticket</th>
      <th>Prix Ticket en promotion</th>
      <th>Date d'evenement</th>
      <th>lieu d'evenement  </th>
      <th>Quantité </th>
      <th>Photo Ticket</th>
      <th>Modifier</th>
      <th>Supprimer</th>
    </tr>
    <tbody>
    <?php 
       $query = "SELECT * FROM ticket" ;
       $query_run = mysqli_query($con, $query);

       if(mysqli_num_rows($query_run) > 0)
       {
           foreach($query_run as $ticket)
           {
               ?>
 <tr>
            <td><?= $ticket['categorie']; ?></td>
            <td><?= $ticket['id']; ?></td>
            <td><?= $ticket['nom_devenement']; ?></td>
            <td><?= $ticket['prix_ticket']; ?></td>
            <td>en promotion</td>
            <td><?= $ticket['date_devenement']; ?></td>
            <td><?= $ticket['lieu_devenement']; ?></td>
            <td><?= $ticket['quantite_ticket']; ?></td>
            
          
          <td><?= $ticket['photo_ticket']; ?><img class="photoTicket"></td>

          <td><a href="modifier.php?id=<?= $ticket['id']; ?>"><img src="images/modifier.png" width="50px" height="50px"></a></td>
          

          <form action="code.php" method="POST" class="d-inline">
          <td><button type="submit" name="delete_ticket" value="<?=$ticket['id'];?>"><img src="images/supprimer.png" width="50px" height="50px"></button></td>
          </form>
        
        </tr>
        <?php
           }
       }
            else {
       echo "<h5> No Record Found </h5>";
       }?>

     
 
  </div>
  </tbody>
</table>
</body>
</html> 