<?php
session_start();
require 'dbcon.php';

if(isset($_POST['delete_ticket']))
{
    $ticket_id = mysqli_real_escape_string($con, $_POST['delete_ticket']);

    $query = "DELETE FROM ticket WHERE id='$ticket_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "ticket Deleted Successfully";
        header("Location: dashboard.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "ticket Not Deleted";
        header("Location: dashboard.php");
        exit(0);
    }
}

if(isset($_POST['update_ticket']))
{
    $ticket_id = mysqli_real_escape_string($con, $_POST['ticket_id']);
    $categorie = mysqli_real_escape_string($con, $_POST['categorie']);
    $nom_devenement = mysqli_real_escape_string($con, $_POST['nom_devenement']);
    $prix_ticket = mysqli_real_escape_string($con, $_POST['prix_ticket']);
    $date_devenement = mysqli_real_escape_string($con, $_POST['date_devenement']);
    $lieu_devenement = mysqli_real_escape_string($con, $_POST['lieu_devenement']);
    $quantite_ticket = mysqli_real_escape_string($con, $_POST['quantite_ticket']);
    $photo_ticket = mysqli_real_escape_string($con, $_POST['photo_ticket']);

    $query = "UPDATE ticket SET categorie='$categorie', nom_devenement='$nom_devenement', prix_ticket='$prix_ticket', date_devenement='$date_devenement', lieu_devenement='$lieu_devenement', quantite_ticket='$quantite_ticket', photo_ticket='$photo_ticket', WHERE id='$ticket_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "ticket Updated Successfully";
        header("Location: dashboard.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "ticket Not Updated";
        header("Location: dashboard.php");
        exit(0);
    }

}


if(isset($_POST['save_ticket']))
{
    
    $categorie = mysqli_real_escape_string($con, $_POST['categorie']);
    $nom_devenement = mysqli_real_escape_string($con, $_POST['nom_devenement']);
    $prix_ticket = mysqli_real_escape_string($con, $_POST['prix_ticket']);
    $date_devenement = mysqli_real_escape_string($con, $_POST['date_devenement']);
    $lieu_devenement = mysqli_real_escape_string($con, $_POST['lieu_devenement']);
    $quantite_ticket = mysqli_real_escape_string($con, $_POST['quantite_ticket']);
    $photo_ticket = mysqli_real_escape_string($con, $_POST['photo_ticket']);

    $query = "INSERT INTO ticket (categorie,nom_devenement,prix_ticket,date_devenement,lieu_devenement,quantite_ticket,photo_ticket) 
    VALUES ('$categorie','$nom_devenement','$prix_ticket','$date_devenement','$lieu_devenement','$quantite_ticket','$photo_ticket')";

    $query_run = mysqli_query($con, $query);
    if($query_run)
    {
        $_SESSION['message'] = "ticket Created Successfully";
        header("Location: Ajouter.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "ticket Not Created";
        header("Location: Ajouter.php");
        exit(0);
    }
}


if(isset($_POST['save_user']))
{
    
    $nom = mysqli_real_escape_string($con, $_POST['nom']);
    $role = mysqli_real_escape_string($con, $_POST['user']);
    $telephone = mysqli_real_escape_string($con, $_POST['telephone']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $mot_passe = mysqli_real_escape_string($con, $_POST['mot_passe']);
   

    $query = "INSERT INTO users (nom,role,telephone,email,mot_passe) 
    VALUES ('$nom','user','$telephone','$email','$mot_passe')";

    $query_run = mysqli_query($con, $query);
    if($query_run)
    {
        $_SESSION['message'] = "user Created Successfully";
        header("Location: register_user.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "user Not Created";
        header("Location: register_user.php");
        exit(0);
    }
}

if(isset($_POST['save_admin']))
{
    
    $nom = mysqli_real_escape_string($con, $_POST['nom']);
    $role = mysqli_real_escape_string($con, $_POST['admin']);
    $telephone = mysqli_real_escape_string($con, $_POST['telephone']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $mot_passe = mysqli_real_escape_string($con, $_POST['mot_passe']);
   

    $query = "INSERT INTO users (nom,role,telephone,email,mot_passe) 
    VALUES ('$nom','admin','$telephone','$email','$mot_passe')";

    $query_run = mysqli_query($con, $query);
    if($query_run)
    {
        $_SESSION['message'] = "user Created Successfully";
        header("Location: register_admin.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "user Not Created";
        header("Location: register_admin.php");
        exit(0);
    }
}

?>



  