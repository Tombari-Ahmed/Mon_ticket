

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="style.css" />
</head>
<body>
<body>
  <style>
    body {
  background-image: url('./assets/images/login.jpg');
}
  </style> 
  
  

<div id="container">
            <form  action="verification.php" method="POST">
            <h1 class="box-logo box-title">welcome User</h1>

            <input name="email" type="text" class="box-input"  placeholder="Adresse e-mail " required="">
            <input type="password" class="box-input"  name="mot_passe" placeholder="Mot de passe" required="">
            <input type="submit" id='submit'  name="btlogin" value='LOGIN' class="box-button" required="">
            <?php
                if(isset($_GET['erreur'])){
                    $err = $_GET['erreur'];
                    if($err==1 || $err==2)
                        echo "<p style='color:red'>Utilisateur ou mot de passe incorrect</p>";
                }
                ?>

            <p class="box-register"> <a href="register_user.php">Créer un nouveau compte d'utilisateur</a></p>
            <p class="box-register"> <a href="login_admin.php"> Admin</a></p>

            </form>
        </div>
        </body>

</html>