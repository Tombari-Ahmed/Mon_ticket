
<!DOCTYPE html>
<html lang="fr">
<head>
  <link rel="stylesheet" href="style.css" />
  <meta charset="utf-8">
</head>
<body>
<body>
  <style>
    body {
  background-image: url('./assets/images/adminlogin.jpg');
}
  </style> 
<div id="container">
            <form  action="verification_admin.php" method="POST">
            <h1 class="box-logo box-title">Bienvenue administrateur</h1>
            <input type="text" class="box-input"  name="email" placeholder="Adresse e-mail d'admin" required="" />
            <input type="password" class="box-input" name="mot_passe" placeholder="Mot de passe d'admin " required="" />
            <input type="submit" id='submit'  name="btlogin" value='LOGIN' class="box-button">
            <?php
                if(isset($_GET['erreur'])){
                    $err = $_GET['erreur'];
                    if($err==1 || $err==2)
                        echo "<p style='color:red'>Utilisateur ou mot de passe incorrect</p>";
                }
                ?>

            <p class="box-register"> <a href="register_admin.php">Créer un nouveau compte d'administrateur</a></p>
            <p class="box-register"> <a href="login_admin.php">Utilisateur</a></p>
         </form>
        </div>
        </body>

<div style="background-image: url('./assets/images/login.jpg');">

</html>