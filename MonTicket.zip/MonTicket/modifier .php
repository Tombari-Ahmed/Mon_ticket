<?php
    session_start();
    require 'dbcon.php';
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Modifier un Ticket</title>
<link rel="stylesheet" href="MonTicket.css">

</head>

<body>


<div id="container">
<?php include('message.php'); ?>
<?php
                        if(isset($_GET['id']))
                        {
                            $ticket_id = mysqli_real_escape_string($con, $_GET['id']);
                            $query = "SELECT * FROM ticket WHERE id='$ticket_id' ";
                            $query_run = mysqli_query($con, $query);

                            if(mysqli_num_rows($query_run) > 0)
                            {
                                $ticket = mysqli_fetch_array($query_run);
                                ?>

	
	<form action="code.php" method="POST">
		<h2 align="center">Mettre à jour un ticket :</h2>

                <label><b> Catégorie</b></label>
                <select class="zonetext" name="categorie" id="categorie" required>
                        <option value="<?=$ticket['name'];?>"><?= $ticket['id']; ?></option>
                        <option value="cinema">Cinéma</option>
                        <option value="musique">Musique</option>
                        <option value="sport">Sport</option>
                        <option value="spectacle ">Spectacle </option>
                    </select>          
                      
                <label><b>Id Ticket</b></label>
                <input class="zonetext" type="text" placeholder="Entrer Id Ticket" name="ticket_id" value="<?=$ticket['id'];?>" required>

                <label><b>Nom d'evenement</b></label>
                <input class="zonetext" type="text" placeholder="Entrer le Nom d'évènement" name="nom_devenement" value="<?=$ticket['nom_devenement'];?>" required>

               <label><b>Prix Ticket</b></label>
                <input class="zonetext" type="text" placeholder="Entrer le Prix de Ticket" name="prix_ticket" value="<?=$ticket['prix_ticket'];?>" required>
              
                <label><b>Date d'evenement</b></label>
                <input class="zonetext" type="date" placeholder="Entrer la Date" name="date_devenement" value="<?=$ticket['date_devenement'];?>" required>
                <label><b>Lieu d'evenement</b></label>
                <input class="zonetext" type="text" placeholder="Entrer la Lieu" name="lieu_devenement" value="<?=$ticket['lieu_devenement'];?>" required>

                <label><b>Quantité de Ticket</b></label>
                <input class="zonetext" type="number" placeholder="Entrer la Quantité" min="1" value="<?=$ticket['quantite_ticket'];?>" name="quantite_ticket" required>

                <label><b>Photo de Ticket</b></label>
                <input class="zonetext" type="file" placeholder="choisir une photo de Ticket" value="<?=$ticket['photo_ticket'];?>" name="photo_ticket" required>
                <input type="submit"  class="submit" name="update_ticket"  >
                
		<p><a href="dashboard.php" class="submit" >Tableau de Bord</a></p>
                
                <label style="text-align: center;color: #360001;">

                	
                	
                	
                </label>
	</form>
	
        <?php
                            }
                            else
                            {
                                echo "<h4>No Such Id Found</h4>";
                            }
                        }
                        ?>
	
</div>



   
 
</body>
</html>