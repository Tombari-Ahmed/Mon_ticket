<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
<link rel="stylesheet" href="style.css" />
</head>
<body>
  <style>
    body {
  background-image: url('./assets/images/adminlogin.jpg');
}
  </style> 
<form class="box" action="code.php" method="post" enctype="multipart/form-data">
  <h1 class="box-logo box-title">welcome </h1>
    <h1 class="box-title">S'inscrire Administrateur</h1>
  <input type="text" class="box-input"  name="nom" placeholder="Nom d'admin" required="" />
    <input type="text" class="box-input"  name="email" placeholder="Adresse e-mail d'admin" required="" />
    <input type="password" class="box-input" name="mot_passe" placeholder="Mot de passe d'admin " required="" />
    <input type="number"  class="box-input" name="telephone" pattern="[0-9]{2}-[0-9]{3}-[0-9]{3}" placeholder="Numéro de téléphone d'admin" required="">
    <input type="submit" name="save_admin" value="save_admin" class="box-button" />
    <p class="box-register">Déjà administrateur ?   <a href="login_admin.php">  Se connecter</a></p>
</form>

</body>
</html>